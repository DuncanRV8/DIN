List<Map<String, dynamic>> gastosAnuales = [
  {
    'mes': 'enero',
    'compras': 4973,
    'bebida': 4345,
    'comida': 3221,
    'ropa': 5471,
    'facturas': 5337
  },
  {
    'mes': 'febrero',
    'compras': 4083,
    'bebida': 4504,
    'comida': 3404,
    'ropa': 3369,
    'facturas': 2932
  },
  {
    'mes': 'marzo',
    'compras': 3785,
    'bebida': 3800,
    'comida': 2972,
    'ropa': 3099,
    'facturas': 3862
  },
  {
    'mes': 'abril',
    'compras': 2051,
    'bebida': 3422,
    'comida': 3901,
    'ropa': 7142,
    'facturas': 3397
  },
  {
    'mes': 'mayo',
    'compras': 4407,
    'bebida': 5547,
    'comida': 3482,
    'ropa': 3056,
    'facturas': 4550
  },
  {
    'mes': 'junio',
    'compras': 4131,
    'bebida': 5096,
    'comida': 4789,
    'ropa': 4664,
    'facturas': 4091
  },
  {
    'mes': 'julio',
    'compras': 4949,
    'bebida': 4918,
    'comida': 4364,
    'ropa': 4224,
    'facturas': 6708
  },
  {
    'mes': 'agosto',
    'compras': 4636,
    'bebida': 5177,
    'comida': 3706,
    'ropa': 4245,
    'facturas': 6551
  },
  {
    'mes': 'septiembre',
    'compras': 5751,
    'bebida': 3142,
    'comida': 6536,
    'ropa': 3262,
    'facturas': 4453
  },
  {
    'mes': 'octubre',
    'compras': 3051,
    'bebida': 5301,
    'comida': 3766,
    'ropa': 3764,
    'facturas': 3688
  },
  {
    'mes': 'noviembre',
    'compras': 4697,
    'bebida': 3773,
    'comida': 4227,
    'ropa': 5097,
    'facturas': 6588
  },
  {
    'mes': 'diciembre',
    'compras': 3795,
    'bebida': 5646,
    'comida': 4466,
    'ropa': 4570,
    'facturas': 4109
  },
];